# Declare variables
budget = 2000
cities = ["Rome", "Nairobi", "Phnom Penh", "Santiago", "Toronto", "Rotorua"]
cities_daily_cost = [150, 70, 60, 80, 110, 125]
days = input("How many days can you travel? ")
city_to_visit = input("What city would you like to visit? ")

# Check if days is a number, and convert it to an integer if it is

# Else print an error


# Check if budget and days are integers, and if so, calculate the daily budget

# Else print an error


# Check if the city_to_visit is in the cities list, and if so,
# get the daily cost for the city

# Else set the city_daily_cost to 0 to be used for error checking


# Check if the city_daily_cost is greater than 0 and equal to or less than the
# daily budget, and if so, tell the traveler they can afford the vacation

# Else if the city_daily_cost is greater than 0 and greater than the daily budget,
# calculate and print out how much more per day the traveler needs

# Else print an error
