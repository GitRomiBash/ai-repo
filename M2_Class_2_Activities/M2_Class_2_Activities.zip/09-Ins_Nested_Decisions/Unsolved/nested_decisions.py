# Nested if-else statements

issue_currency = "EUR"
price = 30.0

# Check if price is not negative (greater than equal to 0)

    # If price is not negative and currency is 'USD' (Dollar).

    # If price is not negative and currency is 'EUR' (Euro).

    # If anything other than the above.


# Else price is negative.


# Nested loops

# Keep looping until we exit the loop


    # Declare user_number


    # Keep looping while user_number is not an integer

        # Ask the user how many numbers to loop through


        # Validate the input is a number


    # Loop through the numbers. (Be sure to cast the string into an integer.)


        # Print each number in the range


        # Limit the range to 20


    # Once complete, ask the user if they want to quit
