# Create a variable and set it as a list


# Methods for accessing parts of a list

# Return the value of a list at a given index


# Return the index of the first object with a matching value


# Return a list slice [index_start:index_end]


# Methods for modifying a list

# Add an element onto the end of a list


# Change a specified element within a list at the given index


# Remove a specified object from a list


# Remove the object at the index specified


# Functions for accessing information about a list
# Define a list named scores
scores = [92, 87, 68, 75, 96]

# Return the max (or highest value) item in a list


# Return the min (or lowest) item in a list


# Return the sum of the items in a list


# Return the length of the list


# Use sum and len to calculate average


# Create a tuple, a sequence of immutable Python objects that cannot be changed


# Information functions also work on tuples, provided they contain valid data
# types
