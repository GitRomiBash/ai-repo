# Declare variables
x = 1
y = 10

# Logical operators: "and" and "or"

# Check for two conditions to be met using "and"


# Check if either of two conditions is met using "or"


# Check if a condition is not true


# Check multiple conditions


# Conditionals with membership operators: "in" and "not in"

# Check if a variable is in a list
name = "Amidah"
group_one = ["Jorge", "Joon", "Susan"]
group_two = ["Gerald", "Paola", "Ryder"]
group_three = ["Farah", "Amidah", "Koen"]



# Check if a variable is not in a list
countries = ["Fiji", "Australia", "New Zealand", "Papua New Guinea", "Palau"
             "Solomon Islands", "Micronesia", "Vanuatu", "Samoa", "Kiribati",
             "Tonga", "Marshall Islands", "Tuvalu", "Nauru"]
country = "Kenya"



# Conditionals with identity operators: "is" and "is not"

# Check if a variable is a list


# Check if a variable is not a list


# Check if a variable is a float or integer


# Check multiple conditions with comparison and logical operators
height = 66
age = 16
adult_permission = True

