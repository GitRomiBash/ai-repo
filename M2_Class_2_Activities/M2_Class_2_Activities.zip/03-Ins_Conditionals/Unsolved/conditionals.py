# Declare variables


# Check if one value is equal to another


# Check if one value is NOT equal to another


# Check if one value is less than another


# Check if one value is greater than another


# Check if a value is greater than or equal to another


# Use a Boolean to check a condition


# Get an input from a user


# Check if the user input is a number
