# Declare lists
rides = []
prices = []

# Continuous loop

    # Keep adding rides until exiting loop


    # Continuous loop

        # Prompt user for the cost of the ride


        # Check if the input is a number

            # Check if the input is less than or equal to 15

                # Convert the input to a float and append it to the prices list

                # Exit the loop



    # Ask the user if they wish to quit, and break the loop if they type 'q'

# Loop through the rides and prices lists by finding the length of rides

    # Set the discount variable to False

    # Check if the price is greater than $5

        # Update the price to include a 10% discount

        # Set the discount variable to true

    # Print the ride name and price, with the price formatted to 2 decimal places

    # If a discount was applied, print a message that says this


    # Print a dash 40 times
