# Loop through a range of numbers (0 through 4)


print("-" * 40)

# Loop through a range of numbers (2 through 6 - yes 6! Up to, but not
# including, 7)


print("-" * 40)

# Loop through a range of numbers (0 through 4) without using the value in the
# range

    # Add 2 to the value of y


print("-" * 40)

# Iterate through letters in a string


print("-" * 40)

# Iterate through a list


print("-" * 40)

# Make changes to each item in a list


print("-" * 40)

# Loop while a condition is being met
run = "y"

# run.lower() means the condition will be met if run = "y" or run = "Y"


# While loop with a Boolean variable
